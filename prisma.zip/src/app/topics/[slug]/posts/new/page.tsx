export default function PostCreatePage() {
  return <div>Post Create Page</div>;
}
